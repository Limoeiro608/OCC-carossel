define(['jquery', 'knockout'], function ($, ko) {
  'use strict'

  return {
    onLoad: function (widget) {
      console.log('static bootstrap 3 carousel')
    },

    beforeAppear: function () {}
  }
})
